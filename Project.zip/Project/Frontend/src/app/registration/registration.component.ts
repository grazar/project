import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { Router } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  constructor(private service: MainService, private router: Router) { }

  denied: boolean;

  user: User = {
    id: 123,
    name: '',
    email: '',
    password: '',
    teacher: true,
    marks: []
  }
  // Реєстрація нового користувача
  registration() {
    if ( this.user.name !== '' && this.user.email !== '' && this.user.password !== ''){
      this.service.addUser(this.user);
      this.router.navigate(['dashboard']);
    } else {
      this.denied = true;
    }
  }

  ngOnInit() {
    this.denied = false;
    this.service.loadUsers();
    this.service.loadTests();
  }

}
