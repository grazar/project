
export class Question {
    id: number
    text: String
    questions: String[]
    answers: boolean[] 
}

export class Test {
    id: number
    questions: Question[]
    title: String
    maxMark: number
}