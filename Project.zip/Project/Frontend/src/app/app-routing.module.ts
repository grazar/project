import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { NewTestComponent } from './new-test/new-test.component';
import { TestsComponent } from './tests/tests.component';
import { ShowMarksComponent } from './show-marks/show-marks.component';
import { TestComponent } from './test/test.component';

//Маршрути дочірніх компонентів для Dashboard
const dashboardChild = [
  { path: 'addtest', component: NewTestComponent },
  { path: 'marks', component: ShowMarksComponent },
  { path: '', component: TestsComponent },
  { path: 'test/:id', component: TestComponent }
]

//Маршрути головних компонентів
const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full'},
  { path: 'login', component: LoginComponent},
  { path: 'registration', component: RegistrationComponent},
  { path: 'dashboard', component: DashboardComponent, children: dashboardChild },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
