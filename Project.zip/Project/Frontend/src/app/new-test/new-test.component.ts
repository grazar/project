import { Component, OnInit } from '@angular/core';
import { NgModule } from '@angular/core';
import { Test, Question } from '../test';
import { MainService } from '../main.service';

@Component({
  selector: 'app-new-test',
  templateUrl: './new-test.component.html',
  styleUrls: ['./new-test.component.css']
})
export class NewTestComponent implements OnInit {

  constructor(private service: MainService) { }

  newTest: Test = {
    id: 12,
    title: '',
    questions: [],
    maxMark: 0
  };
  newQuestion: Question ={
    id: 123,
    text: '',
    questions: [],
    answers: [false, false, false, false] 
  };
  rightAnswer: number;
  
  // Додати питання до тесту
  addQuestion () {
    this.newQuestion.answers[this.rightAnswer - 1] = true;
    this.newTest.questions.push(this.newQuestion);
    this.newQuestion ={
      id: 123,
      text: '',
      questions: [],
      answers: [false, false, false, false] 
    };
    this.rightAnswer = 0;
  }

  // Зберегти тест
  addTest() {
    this.service.addTest(this.newTest);
    this.newTest = {
      id: 12,
      title: '',
      questions: [],
      maxMark: 0
    };
    this.newQuestion ={
      id: 12,
      text: '',
      questions: [],
      answers: [false, false, false, false] 
    };
    this.rightAnswer = 0;
  }

  ngOnInit() {
  }

}
