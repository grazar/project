import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Test, Question} from '../test';
import { MainService } from '../main.service';
import { Mark } from '../user';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  id: number;
  test: Test;
  noResult: boolean;
  question: Question;
  index: number;
  mark: number;
  result: Mark;
  radioSel:any;
  radioSelected:string;
  radioSelectedString:string;

  constructor(private activateRoute: ActivatedRoute, private service: MainService) {
    this.id = activateRoute.snapshot.params['id'];
    
   }

  isRight(){
    this.radioSel = 
    this.radioSelectedString = JSON.stringify(this.radioSel);
  }

  // Збереження відповіді та перехід на нове питання
  next(n) {
    const answerI = this.question.questions.indexOf(this.radioSelected);
    if (this.question.answers[answerI]) {
      this.result.studentMark += this.mark;
    } 
    if ( this.index < this.test.questions.length - 1) {
      this.index++;
      this.question = this.test.questions[this.index];
    } else {
      this.noResult = false;
      console.log('Result: ',this.result);
      this.service.addMark(this.result);
    }
  }

  ngOnInit() {
    const tests = this.service.getTests();
    this.test = tests[this.id];
    this.noResult = true;
    this.index = 0;
    this.question = this.test.questions[0];
    this.mark = this.test.maxMark / this.test.questions.length;
    this.result = {
      id: 12,
      title: this.test.title,
      studentMark: 0,
      maxMark: this.test.maxMark
    }
  }

}
