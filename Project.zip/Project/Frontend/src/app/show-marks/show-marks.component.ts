import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { User } from '../user';

@Component({
  selector: 'app-show-marks',
  templateUrl: './show-marks.component.html',
  styleUrls: ['./show-marks.component.css']
})
export class ShowMarksComponent implements OnInit {

  constructor(private service: MainService) { }

  users: User[];

  ngOnInit() {
    this.users = this.service.getUsers(); 
    console.log(this.users);
  }

}
