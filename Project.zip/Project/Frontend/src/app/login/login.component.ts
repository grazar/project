import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service: MainService, private router: Router) { }

  denied = false;

  // Вхід користувача
  login(email, password) {
    if (this.service.login(email, password)) {
      this.router.navigate(['dashboard']);
    } else {
      this.denied = true;
    }
  }

  // Перенаправлення на сторінку реєстрації
  register() {
    this.router.navigate(['registration']);
  }

  ngOnInit() {
    this.service.startApplication();
  }

}
