import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private service: MainService, private router: Router) { }

  // Вихід користувача
  logout() { 
    this.service.logout();
    this.router.navigate(['login']);
  }

  addtest = false;   

  ngOnInit() {
    // Перевірка чи може поточний користувач додавати тести
    if (this.service.getCurrentUser()) {
      this.addtest = this.service.currentUser.teacher;
      console.log(this.addtest)
    } else {
      this.addtest = false;
    }
    
  }

}
