import { Component, OnInit } from '@angular/core';
import { MainService } from '../main.service';
import { Test } from '../test';
import { Router } from '@angular/router';


@Component({
  selector: 'app-tests',
  templateUrl: './tests.component.html',
  styleUrls: ['./tests.component.css']
})
export class TestsComponent implements OnInit {

  constructor(private service: MainService, private router: Router) { }

  tests: Test[];

  // Перенаправлення на проходження тесту
  goToTest(id: number) {
    this.router.navigate([`dashboard/test/${id}`]);
  }

  ngOnInit() {
    this.tests = this.service.getTests();
  }

}
