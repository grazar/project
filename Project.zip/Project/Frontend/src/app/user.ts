export class Mark {
    id: number
    title: String
    studentMark: number
    maxMark: number
}

export class User {
    id: number
    name: String
    teacher: boolean
    email: String
    password: String
    marks: Mark[]
}