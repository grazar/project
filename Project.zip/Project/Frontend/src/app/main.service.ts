import { Injectable } from '@angular/core';
import { User, Mark } from './user';
import { Test } from './test';
import { HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MainService{

  // Масив усіх користувачів
  users: any;
  // Масив усіх тестів
  tests: any;
  // Активний користувач
  currentUser: User = null;

  // Вихід користувача
  logout() { 
    this.currentUser = null;
  }

  // Вхід користувача
  login(email: String, password: String): boolean {
    const user = this.users.filter(item => { return item.email === email && item.password === password })[0];
    console.log(user);
    if (user) {
      this.currentUser = user;
      return true;
    } 
    else {
      return false;
    }
  }

  // Отримати всі тести
  getTests () : Test[] {
    return this.tests;
  }

  // Завантажити всіх користувачів
  loadUsers() {
    this.http.get('http://localhost:8082/user').subscribe((data) => this.users = data);
  }

  // Завантажити тести
  loadTests() {
    this.http.get('http://localhost:8082/test').subscribe((data) => { this.tests = data });
  }

  // Отримати всіх користувачів
  getUsers (): User[] {
    return this.users;
  }

  // Отримати поточного користувача
  getCurrentUser (): User {
    return this.currentUser;
  }

  // Додати новий тест
  addTest (newTest: Test) {
    this.http.post('http://localhost:8082/test', newTest).subscribe( () => { this.loadTests });
  }

  // Додати новий результат проходження тесту для поточного користувача
  addMark(result) {
    console.log('Current User: ', this.currentUser)
    this.currentUser.marks.push(result);
    return this.http.post('http://localhost:8082/user', this.currentUser).subscribe(() => { this.loadUsers; });
  }

  // Додати нового користувача ( Зареєструвати )
  addUser (newUser: User) {
    console.log(newUser)
    this.currentUser = newUser;
    return this.http.post('http://localhost:8082/user', newUser).subscribe(() => { this.loadUsers; });
  }

  // Завантаження всіх даних з бекенду перед початком роботи
  startApplication() {
    this.loadUsers();
    this.loadTests();

  }

  constructor(private http: HttpClient) { }
}
