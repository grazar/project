package com.kpi.voting.dao.entity;

import javax.persistence.*;

@Entity
public class TestQuestion {
    public String toString() {
        return "TestQuestion{" +
                "id='" + id + '\'' +
                ", text='" + text + '\'' +
                ", answers='" + answers + '\'' +
                ", questions='" + questions + '\'' +
                '}';
    }
    @Id
    @GeneratedValue
    private Long id;
    @Column
    private String text;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String[] getQuestions() {
        return questions;
    }

    public void setQuestions(String[] questions) {
        this.questions = questions;
    }

    public boolean[] getAnswers() {
        return answers;
    }

    public void setAnswers(boolean[] answers) {
        this.answers = answers;
    }

    public Test getTest() {
        return test;
    }

    public void setTest(Test test) {
        this.test = test;
    }

    @Column
    private String[] questions;
    @Column
    private boolean[] answers;
    @ManyToOne
    @JoinColumn(name = "test_id")
    private Test test;
}
