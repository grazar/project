package com.kpi.voting.dao.entity;

import javax.persistence.*;

@Entity
public class Mark {
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getStudentMark() {
        return studentMark;
    }

    public void setStudentMark(Long studentMark) {
        this.studentMark = studentMark;
    }

    public Long getMaxMark() {
        return maxMark;
    }

    public void setMaxMark(Long maxMark) {
        this.maxMark = maxMark;
    }

    @Override
    public String toString () {
        return "Mark{" +
                "id=" + id +
                ", title=" + title + '\'' +
                ", studentMark=" + studentMark +
                ", maxMark=" + maxMark +
                '}';
    }

    @Id
    @GeneratedValue
    private Long id;
    private String title;
    private Long studentMark;
    private Long maxMark;
    public Mark (){

    }
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
