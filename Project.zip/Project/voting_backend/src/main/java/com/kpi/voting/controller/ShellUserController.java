package com.kpi.voting.controller;

import com.kpi.voting.dao.entity.Mark;
import com.kpi.voting.dao.entity.User;
import com.kpi.voting.domain.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class ShellUserController {

    @Autowired
    private UserService userService;

    @GetMapping("/user")
    private List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @PostMapping("/user/{id}")
    private Long addUserMark(@PathVariable("id") Long id, @RequestBody Mark mark ) {
        userService.addUserMarkById(mark, id);
        return id;
    };

    @PostMapping("/user")
    private Long saveUser(@RequestBody User user) {
        userService.saveOrUpdate(user);
        return user.getId();
    }
}
