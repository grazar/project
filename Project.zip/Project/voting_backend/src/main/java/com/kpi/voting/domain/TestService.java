package com.kpi.voting.domain;

import com.kpi.voting.dao.TestRepository;
import com.kpi.voting.dao.entity.Test;
import com.kpi.voting.dao.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TestService {
    @Autowired
    private TestRepository testRepository;

    public List<Test> getAllUsers() {
        List<Test> tests = new ArrayList<>();
        testRepository.findAll().forEach(test -> tests.add(test));
        return tests;
    }


    public void saveOrUpdate(Test test) {
        testRepository.save(test);
    }
}
