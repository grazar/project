package com.kpi.voting.dao.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class User {

    public Long getId() {
        return id;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", isTeacher='" + teacher +
                ", marks='" + marks +
                ", chat='" + chat +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Id
    @GeneratedValue
    private Long id;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isTeacher() {
        return teacher;
    }

    public void setTeacher(boolean teacher) {
        this.teacher = teacher;
    }

    public List<Mark> getMarks() {
        return marks;
    }

    public void setMarks(List<Mark> marks) {
        this.marks = marks;
    }

    @Column
    private String name;
    @Column
    private String email;
    @Column
    private String password;
    @Column
    private boolean teacher;
    @OneToMany(cascade = {CascadeType.ALL})
    private List<Mark> marks;

    public List<Message> getChat() {
        return chat;
    }

    public void setChat(List<Message> chat) {
        this.chat = chat;
    }

    @OneToMany(cascade = {CascadeType.ALL})
    private List<Message> chat;
    public User() {
        marks = new ArrayList<Mark>();
        chat = new ArrayList<Message>();
    }
}
