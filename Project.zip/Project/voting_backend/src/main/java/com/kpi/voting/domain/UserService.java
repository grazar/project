package com.kpi.voting.domain;

import com.kpi.voting.dao.User_repository;
import com.kpi.voting.dao.entity.Mark;
import com.kpi.voting.dao.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private User_repository userRepository;

    public List<User> getAllUsers() {
        List<User> users = new ArrayList<User>();
        userRepository.findAll().forEach(user -> users.add(user));
        return users;
    }

    public void addUserMarkById(Mark newMark, Long id) {
         User user = userRepository.findById(id).get();
         List<Mark> marks =  user.getMarks();
         marks.add(newMark);
         user.setMarks(marks);
         userRepository.save(user);
    }

    public void saveOrUpdate(User user) {
        userRepository.save(user);
    }
}
