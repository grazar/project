package com.kpi.voting.dao.entity;

import javax.persistence.*;
import java.util.List;

@Entity
public class Test {
    @Id
    @GeneratedValue
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<TestQuestion> getQuestions() {
        return questions;
    }

    public void setQuestions(List<TestQuestion> questions) {
        this.questions = questions;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getMaxMark() {
        return maxMark;
    }

    public void setMaxMark(double maxMark) {
        this.maxMark = maxMark;
    }

    @OneToMany(cascade = {CascadeType.ALL})
    private List<TestQuestion> questions;
    @Column
    private String title;
    @Column
    private double maxMark;
    @Override
    public String toString() {
        return "Test{" +
                "id=" + id +
                ", questions='" + questions + '\'' +
                ", title='" + title + '\'' +
                ", maxMark='" + maxMark +
                '}';
    };
}
