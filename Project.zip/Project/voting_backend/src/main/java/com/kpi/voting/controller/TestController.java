package com.kpi.voting.controller;

import com.kpi.voting.dao.entity.Test;
import com.kpi.voting.domain.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
public class TestController {
    @Autowired
    private TestService testService;

    @GetMapping("/test")
    private List<Test> getAllTests() {
        return testService.getAllUsers();
    }


    @PostMapping("/test")
    private Long saveTest(@RequestBody Test user) {
        testService.saveOrUpdate(user);
        return user.getId();
    }
}
